/* Mutfak Stok Uygulaması — frontend */
const $ = (s) => document.querySelector(s);
const state = { user: null, items: [], search: "", category: "" };

const UNITS = ["adet", "kg", "lt", "tane", "paket", "ekmek", "bardak", "kase", "pazar", "sap", "dilim"];

function esc(s) {
  return String(s ?? "").replace(/[&<>"']/g, (c) =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

function fmt(n) {
  return parseFloat(Number(n).toFixed(2)).toString();
}

let toastTimer = null;
function toast(msg, kind = "info") {
  const t = $("#toast");
  t.textContent = msg;
  t.className = "toast show " + kind;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => (t.className = "toast"), 2600);
}

async function api(url, opts = {}) {
  const r = await fetch(url, {
    method: opts.method || "GET",
    headers: { "Content-Type": "application/json" },
    body: opts.body ? JSON.stringify(opts.body) : undefined,
  });
  let data = {};
  try { data = await r.json(); } catch (e) { /* boş */ }
  if (!r.ok) {
    if (!opts.silent) toast(data.error || "Bir hata oluştu", "error");
    throw new Error(data.error || r.status);
  }
  return data;
}

/* ---------- Ekranlar ---------- */
function showAuth() {
  $("#auth-screen").classList.remove("hidden");
  $("#app-screen").classList.add("hidden");
}
function showApp() {
  $("#auth-screen").classList.add("hidden");
  $("#app-screen").classList.remove("hidden");
}

async function boot() {
  try {
    const me = await api("/api/me", { silent: true });
    state.user = me.user;
    enterApp();
  } catch (e) {
    showAuth();
  }
}

async function enterApp() {
  showApp();
  $("#user-name").textContent = state.user.name;
  const roleEl = $("#user-role");
  roleEl.textContent = state.user.role === "admin" ? "Yönetici" : "Görüntüleyici";
  roleEl.className = "role-badge " + state.user.role;
  const isAdmin = state.user.role === "admin";
  $("#btn-new-item").classList.toggle("hidden", !isAdmin);
  $("#btn-users").classList.toggle("hidden", !isAdmin);
  await loadItems();
}

/* ---------- Malzemeler ---------- */
async function loadItems() {
  const { items } = await api("/api/items");
  state.items = items;
  renderItems();
}

function filteredItems() {
  const q = state.search.trim().toLowerCase();
  return state.items.filter((it) => {
    const matchQ = !q || it.name.toLowerCase().includes(q);
    const matchCat = !state.category || it.category === state.category;
    return matchQ && matchCat;
  });
}

function renderStats() {
  const low = state.items.filter((it) => it.quantity <= it.threshold && it.quantity > 0).length;
  const empty = state.items.filter((it) => it.quantity <= 0).length;
  $("#stats").innerHTML = `
    <div class="stat"><b>${state.items.length}</b><span>Malzeme</span></div>
    <div class="stat ${low ? "warn" : ""}"><b>${low + empty}</b><span>Azalmış / Tükendi</span></div>
  `;
}

function expiryBadge(expiry) {
  if (!expiry) return "";
  const today = new Date();
  const d = new Date(expiry + "T00:00:00");
  const days = Math.round((d - today) / 86400000);
  if (days < 0) return `<span class="badge expired">Sünmüş (${-days} gün)</span>`;
  if (days <= 7) return `<span class="badge warn">${days} gün kaldı</span>`;
  return `<span class="badge ok">${days} gün kaldı</span>`;
}

function renderItems() {
  renderStats();

  // kategori filter seçenekleri
  const cats = [...new Set(state.items.map((it) => it.category).filter(Boolean))].sort();
  const sel = $("#category-filter");
  const cur = state.category;
  sel.innerHTML = `<option value="">Tüm kategoriler</option>` +
    cats.map((c) => `<option ${c === cur ? "selected" : ""}>${esc(c)}</option>`).join("");

  const list = filteredItems();
  $("#empty").classList.toggle("hidden", list.length > 0);
  $("#items-grid").innerHTML = list.map((it) => {
    const low = it.quantity <= it.threshold && it.quantity > 0;
    const zero = it.quantity <= 0;
    const cls = zero ? "zero" : low ? "low" : "";
    const exp = expiryBadge(it.expiry);
    return `
      <div class="item-card ${cls}">
        <div class="item-top">
          <div>
            <div class="item-name">${esc(it.name)}</div>
            ${it.category ? `<div class="item-cat">${esc(it.category)}</div>` : ""}
          </div>
          ${exp}
        </div>
        <div class="item-qty">${fmt(it.quantity)}<small>${esc(it.unit)}</small></div>
        <div class="item-actions">
          <button class="btn btn-sm btn-plus" data-id="${it.id}">+</button>
          <button class="btn btn-sm btn-minus" data-id="${it.id}">−</button>
          ${state.user.role === "admin" ? `
            <button class="btn btn-sm btn-edit" data-id="${it.id}">Düzenle</button>
            <button class="btn btn-sm btn-danger btn-del" data-id="${it.id}">Sil</button>` : ""}
        </div>
      </div>`;
  }).join("");
}

/* ---------- Hareketler ---------- */
async function openMovements() {
  const { movements } = await api("/api/movements");
  const rows = movements.map((m) => `
    <div class="move-row">
      <div>
        <div class="m-item">${esc(m.item_name)}</div>
        <div class="m-meta">${esc(m.user_name)} · ${esc(m.created_at)}${m.note ? " · " + esc(m.note) : ""}</div>
      </div>
      <div class="${m.amount >= 0 ? "amount-pos" : "amount-neg"}">
        ${m.amount >= 0 ? "+" : ""}${fmt(m.amount)} ${esc(m.item_unit)}
      </div>
    </div>`).join("");
  openModal(`<button class="modal-close" data-close>×</button><h2>Stok Hareketleri</h2>
    <div class="move-list">${rows || "Henüz hareket yok."}</div>`);
}

/* ---------- Kullanıcılar (yönetici) ---------- */
async function openUsers() {
  const { users } = await api("/api/users");
  const rows = users.map((u) => `
    <div class="user-row">
      <div>
        <div class="u-name">${esc(u.name)} ${u.id === state.user.id ? "<small>(sizin)</small>" : ""}</div>
        <div class="u-username">@${esc(u.username)}</div>
      </div>
      <div style="display:flex;gap:8px;align-items:center">
        <span class="role-badge ${u.role}">${u.role === "admin" ? "Yönetici" : "Görüntüleyici"}</span>
        ${u.role === "admin"
          ? `<button class="btn btn-sm btn-danger" data-role="viewer" data-uid="${u.id}">Yönetici değil</button>`
          : `<button class="btn btn-sm" data-role="admin" data-uid="${u.id}">Yönetici Yap</button>`}
        <button class="btn btn-sm" data-passwd="${u.id}" data-name="${esc(u.name)}">Şifre Değiştir</button>
        ${u.id !== state.user.id ? `<button class="btn btn-sm btn-danger" data-del-user="${u.id}">Sil</button>` : ""}
      </div>
    </div>`).join("");
  openModal(`<button class="modal-close" data-close>×</button><h2>Kullanıcılar</h2>
    <div class="move-list">${rows}</div>`);
}

async function changeRole(uid, role) {
  await api(`/api/users/${uid}/role`, { method: "POST", body: { role } });
  toast("Rol güncellendi", "success");
  openUsers();
}

async function deleteUser(uid) {
  if (!confirm("Bu kullanıcıyı silmek istiyor musunuz?")) return;
  await api(`/api/users/${uid}`, { method: "DELETE" });
  toast("Kullanıcı silindi", "success");
  openUsers();
}

/* ---------- Şifre değiştirme ---------- */
function openPasswordModal(uid, name) {
  const self = uid === state.user.id;
  openModal(`
    <button class="modal-close" data-close>×</button>
    <h2>${self ? "Şifre Değiştir" : "Şifre Sıfırla — ${esc(name)}"}</h2>
    <form id="passwd-form">
      ${self ? `<label>Mevcut şifre <input name="old" type="password" required></label>` : ""}
      <label>Yeni şifre (en az 4 karakter) <input name="new" type="password" required minlength="4"></label>
      <label>Yeni şifreyi tekrar <input name="new2" type="password" required minlength="4"></label>
      <button type="submit" class="btn btn-primary btn-block">Kaydet</button>
    </form>`);

  $("#passwd-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    const f = new FormData(e.target);
    if (f.get("new") !== f.get("new2")) {
      toast("Yeni şifreler eşleşmiyor", "error");
      return;
    }
    try {
      if (self) {
        await api("/api/password", { method: "POST", body: { old: f.get("old"), new: f.get("new") } });
      } else {
        await api(`/api/users/${uid}/password`, { method: "POST", body: { new: f.get("new") } });
      }
      toast("Şifre güncellendi", "success");
      closeModal();
    } catch (err) { /* toast hata zaten gösterildi */ }
  });
}

$("#btn-password").addEventListener("click", () => openPasswordModal(state.user.id, state.user.name));

/* ---------- Malzeme form ---------- */
function openItemForm(item) {
  const editing = !!item;
  const opts = UNITS.map((u) => `<option ${item && item.unit === u ? "selected" : ""}>${u}</option>`).join("");
  openModal(`
    <button class="modal-close" data-close>×</button>
    <h2>${editing ? "Malzeme Düzenle" : "Malzeme Ekle"}</h2>
    <form id="item-form">
      <label>Adı <input name="name" required value="${esc(item?.name || "")}"></label>
      <label>Birim
        <select name="unit">${opts}
          ${item && !UNITS.includes(item.unit) ? `<option selected>${esc(item.unit)}</option>` : ""}
        </select>
      </label>
      <label>Miktar <input name="quantity" type="number" step="0.01" value="${item?.quantity ?? 0}"></label>
      <label>Kategori <input name="category" value="${esc(item?.category || "")}" placeholder="ör. Süt ürünleri"></label>
      <label>Son Kullanma Tarihi <input name="expiry" type="date" value="${esc(item?.expiry || "")}"></label>
      <label>Düşük stok eşiği <input name="threshold" type="number" step="0.01" value="${item?.threshold ?? 0}"></label>
      <button type="submit" class="btn btn-primary btn-block">Kaydet</button>
    </form>`);

  $("#item-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    const f = new FormData(e.target);
    const body = {
      name: f.get("name"), unit: f.get("unit"), quantity: f.get("quantity"),
      category: f.get("category"), expiry: f.get("expiry"), threshold: f.get("threshold"),
    };
    if (editing) {
      await api(`/api/items/${item.id}`, { method: "PUT", body });
      toast("Malzeme güncellendi", "success");
    } else {
      await api("/api/items", { method: "POST", body });
      toast("Malzeme eklendi", "success");
    }
    closeModal();
    loadItems();
  });
}

async function deleteItem(id) {
  if (!confirm("Bu malzemeyi silmek istiyor musunuz?")) return;
  await api(`/api/items/${id}`, { method: "DELETE" });
  toast("Malzeme silindi", "success");
  loadItems();
}

/* ---------- Stok hareketi ---------- */
function openMoveForm(item) {
  openModal(`
    <button class="modal-close" data-close>×</button>
    <h2>${esc(item.name)} — Stok Güncelle</h2>
    <p style="color:var(--muted);font-size:13px;margin-bottom:12px">Mevcut miktar:
      <b>${fmt(item.quantity)} ${esc(item.unit)}</b></p>
    <div class="quick-move">
      <button class="btn" data-quick="1">+1</button>
      <button class="btn" data-quick="5">+5</button>
      <button class="btn" data-quick="-1">−1</button>
      <button class="btn" data-quick="-0.5">−0.5</button>
    </div>
    <form id="move-form">
      <label>Miktar (olumlu = ekle, olumsuz = kullan)
        <input name="amount" type="number" step="0.01" required placeholder="ör. 2 ya da -1"></label>
      <label>Not (isteğe bağlı) <input name="note" placeholder="ör. Kahvaltıda kullanıldı"></label>
      <button type="submit" class="btn btn-primary btn-block">Kaydet</button>
    </form>`);

  document.querySelectorAll("[data-quick]").forEach((b) => {
    b.addEventListener("click", () => {
      document.querySelector('[name="amount"]').value = b.dataset.quick;
    });
  });

  $("#move-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    const f = new FormData(e.target);
    await api(`/api/items/${item.id}/move`, {
      method: "POST",
      body: { amount: f.get("amount"), note: f.get("note") },
    });
    toast("Stok güncellendi", "success");
    closeModal();
    loadItems();
  });
}

/* ---------- Modal yardımcı ---------- */
function openModal(html) {
  $("#modal").innerHTML = html;
  $("#modal-overlay").classList.remove("hidden");
}
function closeModal() {
  $("#modal-overlay").classList.add("hidden");
  $("#modal").innerHTML = "";
}
$("#modal-overlay").addEventListener("click", (e) => {
  if (e.target.id === "modal-overlay" || e.target.hasAttribute("data-close")) closeModal();
});

/* ---------- Wire up ---------- */
document.querySelectorAll(".auth-tab").forEach((tab) => {
  tab.addEventListener("click", () => {
    document.querySelectorAll(".auth-tab").forEach((t) => t.classList.remove("active"));
    tab.classList.add("active");
    const isLogin = tab.dataset.tab === "login";
    $("#login-form").classList.toggle("hidden", !isLogin);
    $("#register-form").classList.toggle("hidden", isLogin);
  });
});

$("#login-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  try {
    const user = await api("/api/login", {
      method: "POST",
      body: { username: $("#login-username").value, password: $("#login-password").value },
    });
    state.user = user;
    toast("Hoş geldiniz!", "success");
    enterApp();
  } catch (err) { /* toast hata zaten gösterildi */ }
});

$("#register-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  try {
    await api("/api/register", {
      method: "POST",
      body: {
        name: $("#reg-name").value,
        username: $("#reg-username").value,
        password: $("#reg-password").value,
      },
    });
    toast("Kayıt başarılı — giriş yapabilirsiniz", "success");
    document.querySelector('[data-tab="login"]').click();
  } catch (err) { /* toast hata zaten gösterildi */ }
});

$("#btn-logout").addEventListener("click", async () => {
  await api("/api/logout", { method: "POST" });
  state.user = null;
  showAuth();
});

$("#search").addEventListener("input", (e) => { state.search = e.target.value; renderItems(); });
$("#category-filter").addEventListener("change", (e) => { state.category = e.target.value; renderItems(); });

$("#items-grid").addEventListener("click", (e) => {
  const id = Number(e.target.dataset.id);
  if (e.target.classList.contains("btn-plus") || e.target.classList.contains("btn-minus")) {
    const item = state.items.find((it) => it.id === id);
    if (item) openMoveForm(item);
  } else if (e.target.classList.contains("btn-edit")) {
    const item = state.items.find((it) => it.id === id);
    if (item) openItemForm(item);
  } else if (e.target.classList.contains("btn-del")) {
    deleteItem(id);
  }
});

$("#btn-new-item").addEventListener("click", () => openItemForm(null));
$("#btn-history").addEventListener("click", openMovements);
$("#btn-users").addEventListener("click", openUsers);

$("#modal").addEventListener("click", (e) => {
  if (e.target.dataset.role) changeRole(Number(e.target.dataset.uid), e.target.dataset.role);
  if (e.target.dataset.delUser) deleteUser(Number(e.target.dataset.delUser));
  if (e.target.dataset.passwd) openPasswordModal(Number(e.target.dataset.passwd), e.target.dataset.name);
});

boot();
