# 🧺 Mutfak Stok Uygulaması

Aile üyelerinin **aynı verilere aynı anda eriştiği**, yöneticilerin stok rakamlarını
değiştirdiği, diğer tüm üyelerin sadece görüntülediği mutfak stok takip uygulaması.

Flask + SQLite ile yazılmış, tarayıcında çalışan sade bir uygulama.

## Özellikler

- **Çoklu kullanıcı / kimlik doğrulama** — her aile üyesi kendi hesabıyla giriş yapır
- **Yetki rolü** — yönetici (malzeme ekler/düzenler/siler, stok rakamları değiştirir), görüntüleyici (sadece görür)
- **Stok hareketleri** — "+2 kg ekle", "-1 adet kullanıldı" formunda kayıtlı tutar, her hareket kimin yaptığı ve notla birlikte kaydedilir
- **Birim desteği** — kg, adet, lt, tane, paket… (istenirse özel birim de eklenebilir)
- **Kategori, son kullanma tarihi, düşük stok eşiği** — tükenen ve yakın tükenen malzemeler renklendirilerek gösterilir
- **Arama ve kategori filtresi**

## Çalıştırma

```bash
pip install flask
python3 app.py
```

Sonra http://localhost:5000 adresini tarayıcıda açın.

**İlk yönetici:** kullanıcı adı `admin`, şifre `admin123`
(ilk kullanımda otomatik oluşturulur — lütfen hemen değiştirin)

## Diğer üyeleri nasıl ekleyebilirim?

1. Giriş ekranındaki **"Kayıt Ol"** düğmesinden üye yeni hesabını oluşturur
2. Yönetici (admin) **"Kullanıcılar"** panelinden o üyeyi **"Yönetici Yap"** düğmesiyle düzenleme yetkisi verir
3. Gönderen kullanıcılar sadece stok rakamlarını görüntüler

## Gerçek yaşamda nasıl kullanılır?

- **Tek cihazda:** evdeki ortak bilgisayardan herkes giriş yapıp kullanabilir.
- **Ayrı cihazlardan:** uygulamayı evinizdeki bir bilgisayarda veya
  ücretsiz hosting servislerinde (Render, Railway, Fly.io) barındırın;
  herkes kendi cihazından `https://...` adresine girsin. Verilerkleri SQLite
  dosyasında ortak tutulduğu için herkes aynı stok rakamlarını görür.

> Not: Bir hosting'e yüklerken `SECRET_KEY` ortam değişkenini değiştirin ve
> `admin` şifresini ilk girişte değiştirin.
