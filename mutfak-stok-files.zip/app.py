"""
Mutfak Stok Uygulaması — Flask + SQLite
Aile üyelerinin aynı verileri gördüğü, yöneticilerin stok rakamlarını değiştirdiği
bir stok takip uygulaması.
"""
import os
import sqlite3
from datetime import datetime
from functools import wraps

from flask import Flask, g, jsonify, request, send_from_directory, session
from werkzeug.security import check_password_hash, generate_password_hash

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.environ.get("KITCHEN_DB", os.path.join(BASE_DIR, "kitchen.db"))

app = Flask(__name__, static_url_path="/static")
app.secret_key = os.environ.get("SECRET_KEY", "mutfak-stok-gecici-anahtar-degistir")

# ---------------------------------------------------------------- DB

def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


@app.teardown_appcontext
def close_db(exception=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'viewer',
    created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    unit TEXT NOT NULL DEFAULT 'adet',
    quantity REAL NOT NULL DEFAULT 0,
    category TEXT DEFAULT '',
    expiry TEXT,
    threshold REAL DEFAULT 0,
    created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS movements (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    item_id INTEGER NOT NULL REFERENCES items(id) ON DELETE CASCADE,
    user_id INTEGER NOT NULL REFERENCES users(id),
    user_name TEXT NOT NULL,
    amount REAL NOT NULL,
    note TEXT DEFAULT '',
    created_at TEXT NOT NULL
);
"""


def init_db():
    d = sqlite3.connect(DB_PATH)
    d.executescript(SCHEMA)
    row = d.execute("SELECT COUNT(*) FROM users").fetchone()
    if row[0] == 0:
        d.execute(
            "INSERT INTO users (username, name, password_hash, role, created_at) VALUES (?,?,?,?,?)",
            ("admin", "Yönetici", generate_password_hash("admin123"), "admin",
             datetime.now().isoformat(timespec="seconds")),
        )
    d.commit()
    d.close()


def log_movement(item_id, user, amount, note=""):
    db = get_db()
    db.execute(
        "INSERT INTO movements (item_id, user_id, user_name, amount, note, created_at) VALUES (?,?,?,?,?,?)",
        (item_id, user["id"], user["name"], amount, note,
         datetime.now().isoformat(timespec="seconds")),
    )


def user_json(row):
    return {"id": row["id"], "username": row["username"],
            "name": row["name"], "role": row["role"]}


# ---------------------------------------------------------------- Auth

def current_user():
    uid = session.get("uid")
    if not uid:
        return None
    return get_db().execute("SELECT * FROM users WHERE id = ?", (uid,)).fetchone()


def login_required(f):
    @wraps(f)
    def wrap(*args, **kwargs):
        user = current_user()
        if user is None:
            return jsonify(error="Giriş yapmalısınız"), 401
        return f(*args, **kwargs)
    return wrap


def admin_required(f):
    @wraps(f)
    def wrap(*args, **kwargs):
        user = current_user()
        if user is None:
            return jsonify(error="Giriş yapmalısınız"), 401
        if user["role"] != "admin":
            return jsonify(error="Bu işlem için yönetici yetkisi gerekiyor"), 403
        return f(*args, **kwargs)
    return wrap


# ---------------------------------------------------------------- API

@app.get("/api/me")
@login_required
def api_me():
    return jsonify(user=user_json(current_user()))


@app.post("/api/login")
def api_login():
    d = request.get_json(force=True)
    row = get_db().execute(
        "SELECT * FROM users WHERE username = ?",
        ((d.get("username") or "").strip(),)
    ).fetchone()
    if not row or not check_password_hash(row["password_hash"], d.get("password") or ""):
        return jsonify(error="Kullanıcı adı veya şifre hatalı"), 401
    session["uid"] = row["id"]
    return jsonify(user=user_json(row))


@app.post("/api/register")
def api_register():
    d = request.get_json(force=True)
    username = (d.get("username") or "").strip()
    name = (d.get("name") or "").strip()
    password = d.get("password") or ""
    if not username or not name or len(password) < 4:
        return jsonify(error="Tüm alanlar zorunlu (şifre en az 4 karakter)"), 400
    db = get_db()
    try:
        db.execute(
            "INSERT INTO users (username, name, password_hash, role, created_at) VALUES (?,?,?,?,?)",
            (username, name, generate_password_hash(password), "viewer",
             datetime.now().isoformat(timespec="seconds")),
        )
        db.commit()
    except sqlite3.IntegrityError:
        return jsonify(error="Bu kullanıcı adı zaten mevcut"), 409
    return jsonify(message="Kaydınız oluşturuldu. Giriş yapabilirsiniz.")


@app.post("/api/logout")
def api_logout():
    session.clear()
    return jsonify(ok=True)


@app.post("/api/password")
@login_required
def api_change_password():
    d = request.get_json(force=True)
    user = current_user()
    if not check_password_hash(user["password_hash"], d.get("old") or ""):
        return jsonify(error="Mevcut şifre hatalı"), 400
    if len(d.get("new") or "") < 4:
        return jsonify(error="Yeni şifre en az 4 karakter olmalıdır"), 400
    db = get_db()
    db.execute("UPDATE users SET password_hash = ? WHERE id = ?",
               (generate_password_hash(d["new"]), user["id"]))
    db.commit()
    return jsonify(message="Şifre değiştirildi")


@app.post("/api/users/<int:uid>/password")
@admin_required
def api_reset_password(uid):
    d = request.get_json(force=True)
    if len(d.get("new") or "") < 4:
        return jsonify(error="Şifre en az 4 karakter olmalıdır"), 400
    db = get_db()
    if db.execute("SELECT id FROM users WHERE id = ?", (uid,)).fetchone() is None:
        return jsonify(error="Kullanıcı bulunamadı"), 404
    db.execute("UPDATE users SET password_hash = ? WHERE id = ?",
               (generate_password_hash(d["new"]), uid))
    db.commit()
    return jsonify(message="Şifre sıfırlandı")


@app.get("/api/items")
@login_required
def api_items():
    rows = get_db().execute("SELECT * FROM items ORDER BY category, name").fetchall()
    return jsonify(items=[dict(r) for r in rows])


@app.post("/api/items")
@admin_required
def api_add_item():
    d = request.get_json(force=True)
    name = (d.get("name") or "").strip()
    if not name:
        return jsonify(error="Malzeme adı boş olamaz"), 400
    unit = (d.get("unit") or "adet").strip() or "adet"
    quantity = float(d.get("quantity") or 0)
    threshold = float(d.get("threshold") or 0)
    category = (d.get("category") or "").strip()
    expiry = (d.get("expiry") or "").strip() or None
    db = get_db()
    cur = db.execute(
        "INSERT INTO items (name, unit, quantity, category, expiry, threshold, created_at) VALUES (?,?,?,?,?,?,?)",
        (name, unit, quantity, category, expiry, threshold,
         datetime.now().isoformat(timespec="seconds")),
    )
    item_id = cur.lastrowid
    if quantity != 0:
        log_movement(item_id, current_user(), quantity, "İlk stok")
    db.commit()
    return jsonify(message="Malzeme eklendi")


@app.put("/api/items/<int:item_id>")
@admin_required
def api_edit_item(item_id):
    d = request.get_json(force=True)
    name = (d.get("name") or "").strip()
    if not name:
        return jsonify(error="Malzeme adı boş olamaz"), 400
    db = get_db()
    row = db.execute("SELECT * FROM items WHERE id = ?", (item_id,)).fetchone()
    if row is None:
        return jsonify(error="Malzeme bulunamadı"), 404
    new_qty = float(d.get("quantity") if "quantity" in d else row["quantity"])
    db.execute(
        "UPDATE items SET name=?, unit=?, quantity=?, category=?, expiry=?, threshold=? WHERE id=?",
        (name, (d.get("unit") or row["unit"]).strip() or "adet", new_qty,
         (d.get("category") or "").strip(), (d.get("expiry") or "").strip() or None,
         float(d.get("threshold") if "threshold" in d else row["threshold"]), item_id),
    )
    if "quantity" in d and new_qty != row["quantity"]:
        log_movement(item_id, current_user(), new_qty - row["quantity"], "Düzenleme")
    db.commit()
    return jsonify(message="Malzeme güncellendi")


@app.delete("/api/items/<int:item_id>")
@admin_required
def api_delete_item(item_id):
    db = get_db()
    row = db.execute("SELECT id FROM items WHERE id = ?", (item_id,)).fetchone()
    if row is None:
        return jsonify(error="Malzeme bulunamadı"), 404
    db.execute("DELETE FROM items WHERE id = ?", (item_id,))
    db.commit()
    return jsonify(message="Malzeme silindi")


@app.post("/api/items/<int:item_id>/move")
@admin_required
def api_move(item_id):
    d = request.get_json(force=True)
    try:
        amount = float(d.get("amount"))
    except (TypeError, ValueError):
        return jsonify(error="Miktar geçerli bir sayı olmalı"), 400
    if amount == 0:
        return jsonify(error="Miktar 0 olamaz"), 400
    db = get_db()
    row = db.execute("SELECT * FROM items WHERE id = ?", (item_id,)).fetchone()
    if row is None:
        return jsonify(error="Malzeme bulunamadı"), 404
    note = (d.get("note") or "").strip()
    db.execute("UPDATE items SET quantity = quantity + ? WHERE id = ?", (amount, item_id))
    log_movement(item_id, current_user(), amount, note)
    db.commit()
    return jsonify(message="Stok güncellendi")


@app.get("/api/movements")
@login_required
def api_movements():
    limit = min(int(request.args.get("limit", 100)), 500)
    rows = get_db().execute(
        "SELECT m.*, i.name AS item_name, i.unit AS item_unit FROM movements m "
        "JOIN items i ON i.id = m.item_id "
        "ORDER BY m.created_at DESC, m.id DESC LIMIT ?", (limit,)
    ).fetchall()
    return jsonify(movements=[dict(r) for r in rows])


@app.get("/api/users")
@admin_required
def api_users():
    rows = get_db().execute("SELECT * FROM users ORDER BY created_at").fetchall()
    return jsonify(users=[user_json(r) for r in rows])


@app.post("/api/users/<int:uid>/role")
@admin_required
def api_set_role(uid):
    d = request.get_json(force=True)
    role = d.get("role")
    if role not in ("admin", "viewer"):
        return jsonify(error="Geçersiz rol"), 400
    db = get_db()
    target = db.execute("SELECT * FROM users WHERE id = ?", (uid,)).fetchone()
    if target is None:
        return jsonify(error="Kullanıcı bulunamadı"), 404
    if target["role"] == "admin" and role == "viewer":
        admin_count = db.execute("SELECT COUNT(*) FROM users WHERE role='admin'").fetchone()[0]
        if admin_count <= 1:
            return jsonify(error="Son yöneticilerin rolü değiştirilemez"), 400
    db.execute("UPDATE users SET role = ? WHERE id = ?", (role, uid))
    db.commit()
    return jsonify(message="Rol güncellendi")


@app.delete("/api/users/<int:uid>")
@admin_required
def api_delete_user(uid):
    db = get_db()
    me = current_user()
    if uid == me["id"]:
        return jsonify(error="Kendi hesabınızı silemezsiniz"), 400
    target = db.execute("SELECT * FROM users WHERE id = ?", (uid,)).fetchone()
    if target is None:
        return jsonify(error="Kullanıcı bulunamadı"), 404
    if target["role"] == "admin":
        admin_count = db.execute("SELECT COUNT(*) FROM users WHERE role='admin'").fetchone()[0]
        if admin_count <= 1:
            return jsonify(error="Son yönetici silinemez"), 400
    db.execute("DELETE FROM users WHERE id = ?", (uid,))
    db.commit()
    return jsonify(message="Kullanıcı silindi")


# ---------------------------------------------------------------- Frontend

@app.get("/")
def index():
    return send_from_directory(os.path.join(BASE_DIR, "templates"), "index.html")


init_db()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)), debug=False)
